close all;
clear all;

srcdir='/nv/hp5/takamitsu3/scratch/Drake.64t.10km.42lev/';
g=9.8;
r=1026;

dz = squeeze(rdmds([srcdir,'DRF']));
z  = rdmds([srcdir,'RC']);
dz0= rdmds([srcdir,'DRF']);
dx  = rdmds([srcdir,'DXC']);
x  = rdmds([srcdir,'XC']);
dy  = rdmds([srcdir,'DYC']);
y  = rdmds([srcdir,'YC']);
f  = 2*(2*pi/86400)*sin(y/180*pi);
d2y= 1/360;
N0 = size(x);
z3d= repmat(z,[N0(1) N0(2) 1]);
dz3d=repmat(dz0,[N0(1) N0(2) 1]);
dx=repmat(dx,[1 1 42]);
dy=repmat(dy,[1 1 42]);

for i=1:72

   disp(['calculating day=',num2str(i*5)]);

   drdx = zeros(N0(1),N0(2),42);
   drdy = zeros(N0(1),N0(2),42);

   drdz=rdmds([srcdir,'Strat'],i*960);
   T=rdmds([srcdir,'T'],i*960);
   S=rdmds([srcdir,'S'],i*960);
   temp=sw_temp(S,T,-z3d,zeros(N0(1),N0(2),42));
   rhoa=sw_dens(S,temp,-z3d) - sw_dens(35*ones(N0(1),N0(2),42),zeros(N0(1),N0(2),42),-z3d);
   rhoa(S==0)=NaN;

   drdx(2:N0(1)-1,:,:)=(rhoa(3:end,:,:)-rhoa(1:end-2,:,:))./(dx(2:end-1,:,:)+dx(1:end-2,:,:));
   drdy(:,2:N0(2)-1,:)=(rhoa(:,3:end,:)-rhoa(:,1:end-2,:))./(dy(:,2:end-1,:)+dy(:,1:end-2,:));
   gradr=sqrt(drdx.^2+drdy.^2);

   % top to bottom thermal wind shear
   Utz=g*nansum(gradr.*dz3d,3)./abs(f)/r;
 
   drdz(drdz>0)=NaN;
   N=sqrt(-g/r*drdz);
   NH=nansum(dz3d.*N,3);
   Ld(:,:,i)=NH./abs(f)*1e-3;
   time(i)=1980+d2y*(5*i-2.5);
   weady(:,:,i)=0.3*Utz./(Ld(:,:,i)*1e3)*86400;

end

save Ld_eady.mat Ld weady time x y
