close all;
clear all;

srcdir='/nv/hp5/takamitsu3/scratch/Drake.64t.10km.42lev/';
g=9.8;
r=1026;

dz = squeeze(rdmds([srcdir,'DRF']));
dz0= rdmds([srcdir,'DRF']);
x  = rdmds([srcdir,'XC']);
y  = rdmds([srcdir,'YC']);
f  = 2*(2*pi/86400)*sin(y/180*pi);
d2y= 1/360;

for i=1:72

   drdz=rdmds([srcdir,'Strat'],i*960);
   drdz(drdz>0)=NaN;

   N=sqrt(-g/r*drdz);
   N0=size(drdz);
   dz3d=repmat(dz0,[N0(1) N0(2) 1]);
   NH=nansum(dz3d.*N,3);

   Ld(:,:,i)=NH./abs(f)*1e-3;
   time(i)=1980+d2y*(5*i-2.5);

end

save Ld.mat Ld x y
